package com.address.contact;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Repository;

@Repository
public class ContactDao
{
	private final String DRIVER = "oracle.jdbc.driver.OracleDriver";
	private final String URL = "jdbc:oracle:thin:@localhost:1521:xe";
	private final String USERID = "ora_user";
	private final String USERPW = "1234";
	
//	Connection 생성 open()
	private Connection open()
	{
		Connection conn = null;
		try
		{
			Class.forName(DRIVER);
			conn = DriverManager.getConnection(URL, USERID, USERPW);
		} catch (ClassNotFoundException e)
		{
			e.printStackTrace();
		} catch (SQLException e)
		{
			e.printStackTrace();
		}
		return conn;
	}
	
////	뉴스 추가 메소드 => addNews() : parameter Newsdto 받아야 한다
//	public void addNews(ContactDto dto) throws Exception{
//		Connection conn 		= open();
//		String sql = "insert into news(newsid, title, img, regdt, content)	"
//				   + " values(												"
//				   + "(select nvl(max(newsid),0) + 1 from news)				"
//				   + ", ?													"
//				   + ", ?													"
//				   + ", sysdate												"
//				   + ", ?)													";
//		PreparedStatement pstmt = conn.prepareStatement(sql);
//		try(conn;pstmt) {
//			pstmt.setString(1, dto.getTitle());
//			pstmt.setString(2, dto.getImg());
//			pstmt.setString(3, dto.getContent());
//			
//			pstmt.executeUpdate();
//		}
//	} // end addNews()

//	연락처 전체 목록 getAll() : parameter x
	public ArrayList<ContactDto> getAll() throws Exception
	{
		Connection conn = open();
		String sql = "SELECT c.contact_id, c.name, c.phone, c.address, g.groupnm, TO_CHAR(c.contact_regdt, 'YYYY-MM-DD') AS contact_regdt  	"
				+	 "FROM contact c, cgroup g						"
				+	 "WHERE c.groupno = g.groupno					";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		
		ArrayList<ContactDto> contactList = new ArrayList<>();
		
		// 데이터베이스 select => list
		ResultSet rs = pstmt.executeQuery();
		
		try(conn; pstmt; rs)
		{
			while(rs.next())
			{
				// 한개의 연락처 저장
				ContactDto dto = new ContactDto();
				dto.setContact_id(rs.getInt("contact_id"));
				dto.setName(rs.getString("name"));
				dto.setPhone(rs.getString("phone"));
				dto.setAddress(rs.getString("address"));
				dto.setGroupnm(rs.getString("groupnm"));
				dto.setContact_regdt(rs.getString("contact_regdt"));
				
				contactList.add(dto);
			}
		}
		return contactList;
	}


	 // end getAll()
	
//	
////	뉴스 상세 => getNews(newsid), return 한개의 뉴스(NewsDto)
//	public NewsDto getNews(int newsid) throws Exception
//	{
//		NewsDto dto = new NewsDto();
//		Connection conn = open();
//		String sql = "select * from news where newsid = '"+newsid+"' ";
//		PreparedStatement pstmt = conn.prepareStatement(sql);
//		ResultSet rs = pstmt.executeQuery();
//		
//		rs.next();
//		dto.setNewsid(rs.getInt("newsid"));
//		dto.setTitle(rs.getString("title"));
//		dto.setImg(rs.getString("img"));
//		dto.setRegdt(rs.getDate("regdt"));
//		dto.setContent(rs.getString("content"));
//		
//		return dto;
//	}
//	
//	연락처 삭제 => return X : void
//	contact_id : 연락처의 고유 번호, 1씩 증가
	public void delContact(int contact_id) throws Exception
	{
		Connection conn = open();
		String sql = "delete from contact where contact_id = " + contact_id;
		PreparedStatement pstmt = conn.prepareStatement(sql);	
		
		try(conn;pstmt)
		{
			if(pstmt.executeUpdate() == 0)
			{
				throw new SQLException("DB error");
			}
		}
	}
//	연락처 추가 시작
	public void addContact(String name, String phone, String address, int groupno) throws Exception {
		Connection conn = open();
		String sql =  " INSERT INTO CONTACT (contact_id, NAME ,PHONE ,ADDRESS , GROUPNO )		"
					+ " VALUES((SELECT nvl(max(CONTACT_ID),0)+1 FROM CONTACT),?,?,?,?)			";
	
	PreparedStatement pstmt = conn.prepareStatement(sql);
	try(conn;pstmt) {
		pstmt.setString(1, name);
		pstmt.setString(2, phone);
		pstmt.setString(3, address);
		pstmt.setInt(4, groupno);
		
		pstmt.executeUpdate();
  }
 } // 연락처 추가 끝
	
//	연락처 수정 시작
	public void editContact(String name, String phone, String address, int groupno, int contact_id) throws Exception {
		Connection conn = open();
		String sql = "update contact			"
				   + "   set name = ? 			"
				   + "     , phone = ?			"
				   + "     , address = ?		"
				   + "     , groupno = ? 		"
				   + " where contact_id = ? 	";
		
	PreparedStatement pstmt = conn.prepareStatement(sql);
	try(conn;pstmt) {
		pstmt.setString(1, name);
		pstmt.setString(2, phone);
		pstmt.setString(3, address);
		pstmt.setInt(4, groupno);
		pstmt.setInt(5, contact_id);
		
		pstmt.executeUpdate();
	}
	
	
	
	} // 연락처 수정 끝
	
//	연락처 회원가입 시작
	public void registerContact(String account_id, String account_pw, String nickname) throws Exception {
		Connection conn = open();
		String sql =  " INSERT INTO ACCOUNT (ACCOUNT_ID, ACCOUNT_PW, NICKNAME)		"
					+ " VALUES(?,?,?)												";
		
		
	PreparedStatement pstmt = conn.prepareStatement(sql);
	try(conn;pstmt) {
		pstmt.setString(1, account_id);
		pstmt.setString(2, account_pw);
		pstmt.setString(3, nickname);	
		
		pstmt.executeUpdate();
	}
	
  } // 연락처 회원가입 끝
	
//	로그인 아이디 비밀번호 일치 하는지 확인하는 메소드
	// 로그인 아이디 비밀번호 일치 확인 및 연락처 정보 가져오기
	public boolean loginContact(String account_id, String account_pw) throws Exception {
	    Connection conn = open();
	    String sql = "SELECT count(*) 								"
	               + "  FROM account a 								"
	               + " WHERE a.account_id = ? 						"
	               + "   AND a.account_pw = ?						";

	   try(PreparedStatement pstmt = conn.prepareStatement(sql)) {
		   
	    pstmt.setString(1, account_id);
	    pstmt.setString(2, account_pw);

	    try (ResultSet rs = pstmt.executeQuery()) {
	        if (rs.next()) {
	            int count = rs.getInt(1); // "count(*)"의 결과는 1열에 있으므로 인덱스 1 사용
	            return count == 1; // count가 1이면 로그인 성공
	        }
	      }
	    }
	    return false; // 로그인 실패
	}

	

	
} // 전체 메소드 끝


























