package com.address.contact;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
@RequestMapping("/contact")

public class ContactController {
	
	@Autowired
	ContactDao dao;
	
// 연락처 추가 시작
	@PostMapping("contact/add")
	public String addContact(@ModelAttribute ContactDto dto) {
		int temp = 0;
		
		if(dto.getGroupnm().equals("가족")) {
			temp = 1;
		}
		else if(dto.getGroupnm().equals("친구")) {
			temp = 2;
		}
		else if(dto.getGroupnm().equals("직장")) {
			temp = 3;
		}
		else {
			temp = 4;
		}
		try {
			dao.addContact(dto.getName(),dto.getPhone(),dto.getAddress(),temp);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/contact/list";
	}// 연락처 추가 끝
	
//	연락처 수정 시작
	@PostMapping("contact/edit")
	public String editContat(@ModelAttribute ContactDto dto) {
		int temp =0;
			
		if(dto.getGroupnm().equals("가족")) {
			temp = 1;
		}
		else if(dto.getGroupnm().equals("친구")) {
			temp = 2;
		}
		else if(dto.getGroupnm().equals("직장")) {
			temp = 3;
		}
		else {
			temp = 4;
		}
		
		try {
			dao.editContact(dto.getName(), dto.getPhone(), dto.getAddress(), temp, dto.getContact_id());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return "redirect:/contact/list";
	
	
	} // 연락처 수정 끝
	
//	연락처 목록
	@GetMapping("/list")
	public String contactlist(Model model) {
		ArrayList<ContactDto> list;
		
		try {
			list=dao.getAll();
			model.addAttribute("listContacts", list);
		} catch (Exception e) {
			e.printStackTrace();
			model.addAttribute("error", "회원 목록 에러");
		}
		return "list";
	}


	
	// 연락처 삭제
	@GetMapping("/delete/{contact_id}")
	public String deletcontact(@PathVariable int contact_id, Model model) {
		try {
			dao.delContact(contact_id);
		} catch (Exception e) {
			e.printStackTrace();
			model.addAttribute("error","회원 삭제 에러");
		}
		return "redirect:/contact/list";
	}
	
	
	
	// 연락처 로그인
	@GetMapping("/login")
	public String logincontact(@ModelAttribute ContactDto dto, Model model) {
	    try {
	        boolean loginResult = dao.loginContact(dto.getAccount_id(), dto.getAccount_pw());
	        if (loginResult) {
	            // 로그인 성공
	            return "redirect:/contact/list"; // 로그인 성공 시 리스트 페이지로 이동
	        } else {
	            // 로그인 실패
	            model.addAttribute("error", "로그인에 실패했습니다. 아이디 또는 비밀번호가 일치하지 않습니다.");
	            return "login";
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	        model.addAttribute("error", "로그인 에러");
	        return "login";
	    }
	}

	// 연락처 로그인 뷰
	@PostMapping("/loginwindow")
	public String loginwindow() {
	    return "login"; // 로그인 화면으로 이동
	}

	// 연락처 회원가입
	@PostMapping("/register")
	public String registerContact(@ModelAttribute ContactDto dto, Model model) {
	    try {
	        dao.registerContact(dto.getAccount_id(), dto.getAccount_pw(), dto.getNickname());
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return "redirect:/contact/login"; // 로그인 페이지로 리디렉션
	}


	// 연락처 회원가입 뷰
	@PostMapping("/registerwindow")
	public String registerwindow() {
	    return "register"; // 회원가입 화면으로 이동
	}
	
} // 전체 메소드 끝	

















